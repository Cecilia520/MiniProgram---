//index.js
// 引用百度地图微信小程序JSAPI模块 
var bmap = require('../../libs/bmap-wx.js'); 
Page({ 
    data: { 
        weatherData: '' 
    }, 
    onLoad: function() { 
        var that = this; 
        // 新建百度地图对象 
        var BMap = new bmap.BMapWX({ 
            ak: 'H7E1YQUbokbNmjBTOcaMAWa4oF9Kyura' 
        }); 
        var fail = function(data) { 
            console.log(data) 
        }; 
        var success = function(data) { 
            var weatherData = data.currentWeather[0]; 
            weatherData = '城市：' + weatherData.currentCity + '\n' + 'PM2.5：' + weatherData.pm25 + '\n' +'日期：' + weatherData.date + '\n' + '温度：' + weatherData.temperature + '\n' +'天气：' + weatherData.weatherDesc + '\n' +'风力：' + weatherData.wind + '\n'; 
            that.setData({ 
                weatherData: weatherData 
            }); 
        } 
        // 发起weather请求 
        BMap.weather({ 
            fail: fail, 
            success: success 
        }); 
    } 
})
//获取应用实例
// var app = getApp()
// Page({
//   data: {
//     weatherApikey: '',//天气API，在http:apistore.baidu.com上
//     city: '',//城市名称
//     areaid: '',//城市对应的地区id
//     curWd: {},//当天天气情况
//     indexs: {},//当天天气详细说明
//     forecast: {}//未来4天的天气情况
//   },
//   //事件处理函数
//   onLoad: function (options) {
//     this.setData({ weatherApikey: getApp().globalData.weatherApikey });
//     this.loadLocation();
//   },
//   onReady: function () {
//     // 生命周期函数---监听页面初次渲染完成
//   },
//   onShow: function () {
//     // 生命周期函数---监听页面显示
//   },
//   onHide: function () {
//     // 生命周期函数---监听页面隐藏
//   },
//   onUnload: function () {
//     // 生命周期函数---监听页面卸载
//   },
//   onPullDownRefresh: function () {
//     // 页面相关事件处理函数---监听用户下拉动作
//   },
//   onReachBottom: function () {
//     // 页面上拉触底事件的处理函数
//   },
//   onShareAppMessage: function () {
//     // 用户右点击上角分享
//     return {
//       title: '城市微天气',//分享标题
//       desc: '今天约女神吗？想知道今天天气怎么样吗？那就一起进入微天气约一波吧！',
//       path: 'path'//分享路径

//     }
//   },
//   // 获取当前的位置信息，即经纬度
//   Loadcation: function () {
//     var page = this;
//     wx.getLocation({
//       type: 'gcj02', // 默认为 wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标
//       success: function (res) {
//         // success
//         var latitude = res.latitude;
//         var longitude = res.longitude;
//         // 获取城市
//         page.loadCity(latitude, longitude);
//       },
//       //通过经纬度获取城市
//       loadCity: function (latitude, longitude) {
//         var page = this;
//         //这个key是自己在http://apistore.baidu.com上申请的
//         var key = "6162261e14e7580c4b2656e8aaab9816";
//         var url = "http://apis.map.qq.com/ws/geocoder/v1/?location=" + latitude + "," + longitude + "&key=" + key + "&get_poi=1";
//         wx.request({
//           url: url,
//           data: {},
//           method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
//           // header: {}, // 设置请求的 header
//           success: function (res) {
//             // success
//             var city = res.data.result.address_component.city;
//             city = city.replace("");
//             page.setData({ city: city });
//             page.loadId(city);
//           }
//         })
//       },

//       //通过城市名称获取城市的唯一ID
//       loadId: function (city) {
//         var page = this;
//         var url = "http://apis.baidu.com/apistore/weatherservice/citylist";
//         wx.request({
//           url: url,
//           data: {
//             cityname: city
//           },
//           header: {
//             apikey: page.data.weatherApikey
//           },
//           method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
//           success: function (res) {
//             // success
//             var cityid = res.data.retData[0].area_id;

//             page.setData({ areaid: cityid });
//             page.loadWeather(city, cityid);
//           }
//         })
//       },

//       //通过城市名称和城市ID获取天气情况
//       loadWeather: function (city, areaId) {
//         var page = this;
//         var url = "http://apis.baidu.com/apistore/weatherservice/recentweathers";
//         wx.request({
//           url: url,
//           data: {
//             cityname: city,
//             cityid: areaId
//           },
//           header: {
//             apikey: page.data.weatherApikey
//           },
//           method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
//           success: function (res) {
//             // success
//             page.setData({ curWd: res.data.retData.today, indexs: res.data.retData.today.index, forecast: res.data.retData.forecast });
//           }
//         })
//       }
//     })
//   }
// })